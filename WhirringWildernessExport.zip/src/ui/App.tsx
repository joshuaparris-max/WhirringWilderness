import { GameScreen } from './GameScreen';

export function App() {
  return <GameScreen />;
}

export default App;

